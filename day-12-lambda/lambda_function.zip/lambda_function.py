
import json

def lambda_handler(event, context):
    # TODO implement
    return {
        'statusCode': 200,
        'body': "Hello this is Mani!"
    }
